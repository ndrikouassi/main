# Mule 3 Deployment Demo

This is a Mule 3 Application deployment demo. See this blog post for more details  - https://javastreets.com/blog/mule-maven-deployment-and-jenkins-pipeline.html

